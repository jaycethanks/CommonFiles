// components/my-component/my-component.js
Component({
  data: {
    name: 'my-component'
  },
  attached() {

  },
  methods: {
    customEventTrigger: function () {
      this.triggerEvent('customEventHandler', {
        anyData: "world"
      })
    }
  }
})