Page({
  data: {
    toggleDisplay:true,
    msg:"hello"
  },
  customEvent:function(event){
    let receiveData = event.detail.anyData;
    this.setData({
      msg:receiveData,
      toggleDisplay:!this.data.toggleDisplay
    })
  },
})
